import React, { Component } from 'react';
import {
  Button,
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  TextInput,
  TouchableHighlight,
  ImageBackground,
  AsyncStorage
} from 'react-native';
import { LoginButton, LoginManager, AccessToken, GraphRequest, GraphRequestManager } from 'react-native-fbsdk';
import { GoogleSignin, GoogleSigninButton, statusCodes } from 'react-native-google-signin';
GoogleSignin.configure({
  scopes: ['https://www.googleapis.com/auth/drive.readonly'], // what API you want to access on behalf of the user, default is email and profile
  webClientId: '822582169843-b0d8jovgsla5tbcggrpuej1250f01udf.apps.googleusercontent.com', // client ID of type WEB for your server (needed to verify user ID and offline access)

});
import Toast from 'react-native-simple-toast';
import Icon from 'react-native-vector-icons/FontAwesome5';
const { width } = Dimensions.get('window');
// const TabNavigator = createBottomTabNavigator({
//   Detail: Detail,
//   Profile: Profile
// });

export default class Signup extends Component {
    state = {
        email: '',
        password: '',
        signup_by: '',
        facebook_id: '',
        emailerror: null,
        passworderror: null,
        showPassword: true,
        icEye: 'eye-slash',
    }
    onChangeText = (key, val) => {
        this.setState({ [key]: val })
    }


    validate_email = (text, submited) => {
      console.log(text);
      let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      let submitted= submited;
    //  if(submited){
  
    //  }
      if(reg.test(text) === false && text.length>0 && submitted==true)
      {
      console.log("Email is Not Correct");
      this.setState({email:text, emailerror: 'Invalid Email'})
      return false;
        }else if(text.length==0 && submitted==true){
          this.setState({email:text, emailerror: 'Email is required'})
          return false;
        } else {
        this.setState({email:text, emailerror: null})
        console.log("Email is Correct");
        return true;
      }
      }
  
  
  validate_password=(text, submitted)=>{
    console.log(text)
    let pwd = text;
    console.log(this.state)
    //let submitted= this.state.formsubmit;
    if(pwd.length==0 && submitted==true){
      console.log('invalid password')
      this.setState({password:pwd, passworderror: 'Password is required'})
      return false; 
    }else if(pwd.length>0 && pwd.length< 7 && submitted==true){
      this.setState({password:pwd, passworderror: 'Password should be at least 7 characters long'})
      return false; 
    } else{
      this.setState({password:pwd, passworderror: null})
      return true;
    }
   
    } 




    signUp =  () => {
        
        try {
      this.setState({'signup_by': 'email'})
      var postdata = this.state

      let validation=false;
      let emailvalidation= this.validate_email(postdata.email, true)
      let passwordvalidation= this.validate_password(postdata.password, true);
      if(emailvalidation==false || passwordvalidation==false){
        return false
      }else{
        validation=true; 
      }
       if(validation==true){
        postdata.signup_by = 'email'

        console.log(postdata)
        fetch('http://202.164.42.26:8282/castlesetup/public/api/v1/signup', {
          method: 'POST',
          headers: { 
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(postdata),
        }).then((response) => response.json())
          .then(async(responseJson) => {
            console.log(responseJson)
              if(responseJson.success==1){
                  await AsyncStorage.setItem('token', responseJson.token);
                 this.props.navigation.navigate('App') 
              }else{
                if(responseJson.success==0){
                  for(let i in responseJson.error){
                    console.log(i)
                    console.log(responseJson.error[i][0])
                    if(i=='email'){
                      Toast.show(responseJson.error[i][0]);
                    }else{
                      Toast.show(responseJson.error);
                    }
                  }
                } 
              }
          }).catch((error) => {
            alert(JSON.stringify(error))
          });

       }
       } catch (err) {
            console.log('error signing up: ', err)
        }
    }

   


      handleFacebooksignup=()=>{
        LoginManager.logInWithReadPermissions(['public_profile', 'email']).then((result)=> {
            if (result.isCancelled) {
              console.log('Login cancelled')
            } else {
              console.log('Login success with permissions: ' + result.grantedPermissions.toString())
              AccessToken.getCurrentAccessToken().then((data) => {
               
                let accessToken=data.accessToken;
                _responseInfoCallback = (error, result) => {
                  if (error) {
                    alert('Error fetching data: ' + error.toString());
                  } else {
                    var postdata = {
                      email: result.email,
                      'signup_by': 'facebook_id',
                       facebook_id: result.id
                    }
                   console.log(postdata);
                    // this.setState({ 'signup_by': 'facebook_id' })
                    // this.setState({ email: result.email,'signup_by': 'facebook_id', facebook_id: result.id});
                    fetch('http://202.164.42.26:8282/castlesetup/public/api/v1/signup', {
                      method: 'POST',
                      headers: {
                        Accept: 'application/json',
                        'Content-Type': 'application/json',
                      },
                      body: JSON.stringify(postdata),
                    }).then((response) => response.json())
                      .then(async(responseJson) => {
                        if(responseJson.success==1){
                            await AsyncStorage.setItem('token', responseJson.token);
                            this.props.navigation.navigate('App')
          
                        }else{
                          alert(JSON.stringify(responseJson))
                        }     
                      })
                      .catch((error) => {
                        alert(JSON.stringify(error))
                      });
              
              
                  //  alert(JSON.stringify(result))
                  }
                }



                const infoRequest = new GraphRequest('/me', {
                  accessToken: accessToken,
                  parameters: { 
                    fields: {
                      string: 'email,name,first_name,middle_name,last_name'
                    }
                  } 
                }, _responseInfoCallback);
                new GraphRequestManager().addRequest(infoRequest).start();






                // const infoRequest = new GraphRequest(
                //   '/me?fields=name,email,picture.type(large)',
                //   null,
                //   this._responseInfoCallback
                // );
                // new GraphRequestManager().addRequest(infoRequest).start();
              })
            }
          },
          function (error) {
            console.log('Login fail with error: ' + error)
          }
        )
      } 


      googlesignUp = async () => {
        try {
          await GoogleSignin.hasPlayServices();
          const userInfo = await GoogleSignin.signIn();
          var postdata = {
            email: userInfo.user.email,
            'signup_by': 'gmail_id',
             gmail_id: userInfo.user.id
          }
         console.log(postdata);
          // this.setState({ 'signup_by': 'gmail_id' })
          // this.setState({ email: userInfo.user.email,'signup_by': 'gmail_id', gmail_id: userInfo.user.id});
          fetch('http://202.164.42.26:8282/castlesetup/public/api/v1/signup', {
            method: 'POST',
            headers: {
              Accept: 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(postdata),
          }).then((response) => response.json())
            .then(async(responseJson) => {
              if(responseJson.success==1){
                await AsyncStorage.setItem('token', responseJson.token);
               //  alert("Sign up successfully");
                 this.props.navigation.navigate('App')
              }else{
                
                alert(JSON.stringify(responseJson))
              }     
            })
            .catch((error) => {
              alert(JSON.stringify(error))
            });
         // this.setState({ userInfo });
        } catch (error) {
          console.log(error)
          console.log(error.code)
          if (error.code === statusCodes.SIGN_IN_CANCELLED) {
            // user cancelled the login flow
          } else if (error.code === statusCodes.IN_PROGRESS) {
            // operation (f.e. sign in) is in progress already
          } else if (error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
            // play services not available or outdated
          } else {
            // some other error happened
          }
        }
      };

      changePwdType = () => {
        console.log("dfdf")
        let newState;
        if (this.state.showPassword) {
            newState = {
                icEye: 'eye',
                showPassword: false,
                password: this.state.password
            }
        } else {
            newState = {
                icEye: 'eye-slash',
                showPassword: true,
                password: this.state.password
            }
        }
        // set new state value
        this.setState(newState)
    };
    
    handlePassword = (password) => {
      let newState = {
          icEye: this.state.icEye,
          showPassword: this.state.showPassword,
          password: password
      }
      this.setState(newState);
      //this.props.callback(password); // used to return the value of the password to the caller class, skip this if you are creating this view in the caller class itself
    };



    render() {
        const { email, password } = this.state
        const emailValid = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(email)
        const passwordValid = (password && password.length >= 8 ? true : false)
        return (


          <View style={styles.container}>
          <TextInput
            style={styles.input}
            onChangeText={(text) => this.validate_email(text, false)}
            placeholder="Email"
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="email-address"
          />
           <Text style={styles.error}>{this.state.emailerror}</Text>
   <View style={{
   width: "100%",
   justifyContent: 'center',
   alignItems: 'center'
 }}>  
          <TextInput
            style={styles.input}
            onChangeText={(password) => this.validate_password(password, false)}
            placeholder="Password"
            autoCapitalize="none"
            autoCorrect={false}
            secureTextEntry={this.state.showPassword} 
          />
           <Text style={styles.error}>{this.state.passworderror}</Text> 
           <Icon style={styles.icon}
                        name={this.state.icEye}
                        size={20}
                        color={componentColors.password_icon_color}
                        onPress={this.changePwdType}
                    />
                    </View> 

           <TouchableHighlight
            onPress={this.signUp}
            style={styles.button}>
            <Text style={{
              textAlignVertical: "center", textAlign: "center",
              color: '#fff', fontSize: 20, textTransform: 'uppercase',
            }}>Sign Up</Text>
       </TouchableHighlight>
       <View>
       <View style={{ 
            flex: 1,
            display: 'flex',
            alignSelf: 'center',
            alignContent: 'center',
            alignItems: 'center',
            width: '30%',
            backgroundColor: '#fff',
            flexDirection: 'row',
            height: 30,
            maxHeight: 30,
            justifyContent: 'space-between',
          }} >
            <View style={{
              height: 5,
              width: 50,
              borderTopColor: '#eee',
              borderTopWidth: 1,

            }}>

            </View>
            <Text
              style={{
                height: 30,
                width: 30,
                textAlign: 'center',
                textAlignVertical: 'center',
                color: '#ddd',
                borderRadius: 15,
                overflow: 'hidden',
                borderBottomColor: '#eee',
                borderBottomWidth: 1,
                borderTopColor: '#eee',
                borderTopWidth: 1,
                borderRightColor: '#eee',
                borderRightWidth: 1,
                borderLeftColor: '#eee',
                borderLeftWidth: 1
              }}
            >OR</Text>
            <View style={{
              height: 5,
              width: 50,
              borderTopColor: '#eee',
              borderTopWidth: 1,

            }}>

            </View>
            </View>
          </View>
          <View style={{
            alignItems: 'center',
          }}>
            <Text>SIGN UP WITH</Text>
          </View>
          <View style={styles.socialmedia}>
            <TouchableHighlight
              onPress={this.googlesignUp}
            >
              <Image source={require('../../assets/google.png')} />
            </TouchableHighlight>
            <TouchableHighlight
              onPress={this.handleFacebooksignup}
            >
              <Image source={require('../../assets/fb.png')} />
            </TouchableHighlight>
          </View>
          <View style={{
            marginBottom: 10
          }}>
            <Text>
             By Joining. You Agree To Our Terms and Conditions 
            </Text>
          </View>
          <View style={{
             position: 'absolute',
             bottom: 0,
             left: 0,
             right: 0,
             height: 30,
          }}> 
            <ImageBackground source={require('../../assets/bottom.png')} style={{ width: '100%', height: 48, resizeMode: "contain" }}>
            </ImageBackground>
          </View>
          </View>
            
        )
    }
}
export const componentColors = {
  password_icon_color:'#9E9E9E',
}; 
const ELEMENT_WIDTH = width - 40;
const styles = StyleSheet.create({
  keyboardstyle:{
    width: '100%',
    backgroundColor: '#eee',
    marginRight:40,
    marginLeft: 20,
  },
  container: { 
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: "#FFFFFF",
    height: "100%"
  },
  input: {
    width: '80%',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderTopColor: '#ccc',
    borderBottomColor: '#ccc',
    borderLeftColor: '#ccc',
    borderRightColor: '#ccc',
    borderRadius: 20,
    height: 40,
    paddingLeft: 15,
    paddingRight: 15,
    marginTop: 20
  },
  button: {
    width: ELEMENT_WIDTH,
    alignItems: 'center',
    borderRadius: 30,
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20,
    marginBottom: 20,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderTopColor: '#881465',
    borderBottomColor: '#881465',
    borderLeftColor: '#881465',
    borderRightColor: '#881465',
    backgroundColor: '#881465',
    height: 60,
    maxWidth: '50%',
    paddingTop: 15,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: '500',
    fontSize: 16,
  },
  socialmedia: {
    display: "flex",
    flexWrap: 'wrap',
    padding: 20,
    maxWidth: '80%',
    alignSelf: 'center',
    width: '70%',
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  error: {
    color: "red",
    textAlign: 'left',
    width : '80%',
    paddingLeft: 15,
    //alignSelf : 'flex-start'
  },
  icon: {
    position: 'absolute',
    top: 30,
    right: 50,
}
 }); 

// const styles = StyleSheet.create({
//     input: {
//         width: 350,
//         height: 55,
//         backgroundColor: '#42A5F5',
//         margin: 10,
//         padding: 8,
//         color: 'white',
//         borderRadius: 14,
//         fontSize: 18,
//         fontWeight: '500',
//     },
//     container: {
//         flex: 1,
//         justifyContent: 'center',
//         alignItems: 'center'
//     }
// })

