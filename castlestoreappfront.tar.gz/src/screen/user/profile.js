import React, { Component } from 'react';
import {
  Button,
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  TextInput,
  TouchableHighlight,
  ImageBackground,
  ActivityIndicator,
  AsyncStorage,
  ScrollView,
  Picker
} from 'react-native';
import PhotoUpload from 'react-native-photo-upload'
import { Avatar } from 'react-native-elements';
import { tsVoidKeyword } from '@babel/types';
import Icon from 'react-native-vector-icons/FontAwesome';
import Toast from 'react-native-simple-toast';
import ImagePicker from 'react-native-image-picker';
const { width } = Dimensions.get('window');
export default class Profile extends Component {
  
  constructor(props) {
    super(props)
    this.state = {
      first_name: {
        text: '',
        valid: false
      },
      last_name: {
        text: '',
        valid: false
      },
      address: {
        text: '',
        valid: false
      },
      city: {
        text: '',
        valid: false
      },
      state: {
        text: '',
        valid: false
      },
      country: {
        text: '',
        valid: false
      },
      zip: {
        text: '',
        valid: false
      },
      gender: {
        text: 'male',
        valid: true
      },
      token: '',
      img_loading: false,
    }
  // this.setState({uri: 'https://s3.amazonaws.com/uifaces/faces/twitter/ladylexy/128.jpg'})
  }






  async componentDidMount() {
    let token = await AsyncStorage.getItem('token');

    this.setState({
      token: token
    })
this.getuserdetail(token);
  }

getuserdetail(token){
  console.log(token)
  fetch('http://202.164.42.26:8282/castlesetup/public/api/v1/get-profile', {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + token

    },
  }).then((response) => response.json())
    .then(async (responseJson) => {
      console.log(responseJson)
      if (responseJson.success == 1) {
        let formdata = this.state
        console.log(formdata)
        for (let i in formdata) {
          if ((Object.keys(formdata[i]).length) > 1 && i != 'token') {
            if (formdata[i].valid == false) {
              validform = false;
              switch (i) {
                case 'first_name':
                  formdata[i].text = responseJson.data.first_name;
                  if(formdata[i].text){
                    if(formdata[i].text.length>0){
                      formdata[i].valid=true;
                    }
                  }
                  
                  break;
                case 'last_name':
                  formdata[i].text = responseJson.data.last_name;
                  if(formdata[i].text){
                  if(formdata[i].text.length>0){
                    formdata[i].valid=true;
                  }
                }
                  break;
                case 'address':
                  formdata[i].text = responseJson.data.address;
                  if(formdata[i].text){
                  if(formdata[i].text.length>0){
                    formdata[i].valid=true;
                  }
                }
                  break;
                case 'city':
                  formdata[i].text = responseJson.data.city;
                  if(formdata[i].text){
                  if(formdata[i].text.length>0){
                    formdata[i].valid=true;
                  }
                }
                  break;
                case 'state':
                  formdata[i].text = responseJson.data.state;
                  if(formdata[i].text){
                  if(formdata[i].text.length>0){
                    formdata[i].valid=true;
                  }
                }
                  break;
                case 'country':
                  formdata[i].text = responseJson.data.country;
                  if(formdata[i].text){
                  if(formdata[i].text.length>0){
                    formdata[i].valid=true;
                  }
                }
                  break;
                case 'zip':
                  formdata[i].text = responseJson.data.zip;
                  if(formdata[i].text != null){
                  if((formdata[i].text.toString().length) > 0){
                    formdata[i].text=formdata[i].text.toString(); 
                    console.log(formdata[i].text)
                    formdata[i].valid=true;
                  }
                } 
                  break;
                case 'gender': 
                  formdata[i].text = responseJson.data.gender;
                  if(formdata[i].text){
                  if(formdata[i].text.length>0){
                    formdata[i].valid=true;
                  }
                } 
                  break; 
                 // case 'avatar':
                    
                   // break;
              }
    
            }
          }
        } 
        this.setState(formdata); 
        console.log(this.state)
        let useravatar= responseJson.url+responseJson.data.avatar;
        this.setState({uri:useravatar});

      } else {
        alert(JSON.stringify(responseJson))
      }
    })
    .catch((error) => {
      console.log(error) 
      alert("Dd")
      alert(JSON.stringify(error))
    });


}
 

selectPhotoTapped() {
  const options = {
    quality: 1.0,
    maxWidth: 500,
    maxHeight: 500,
    storageOptions: {
      skipBackup: true,
      path: 'images'
    }
  };   
  ImagePicker.showImagePicker(options, (response) => {
    console.log('Response = ', response);

    if (response.didCancel) {
      console.log('User cancelled photo picker');
    }
    else if (response.error) {
      console.log('ImagePicker Error: ', response.error);
    }
    else if (response.customButton) {
      console.log('User tapped custom button: ', response.customButton);
    }
    else {
   //   let source = { uri: response.uri };
     // console.log(source)
      this.getusertoken(response.data)
    }
  });
}


  getusertoken(evt) {

    let postdata = {
      avatar: evt
    }
    let token = this.state.token;
    this.setState({img_loading: true})
    console.log(token)
    fetch('http://202.164.42.26:8282/castlesetup/public/api/v1/avatar', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token

      },
      body: JSON.stringify(postdata),
    }).then((response) => response.json())
      .then(async (responseJson) => {
        console.log(responseJson)
        if (responseJson.success == 1) {
          let useravtar=responseJson.url+responseJson.data.avatar+'?data'+new Date();
          this.setState({uri:useravtar, img_loading: false})
          Toast.show('Profile image changed successfuly');
        //  await AsyncStorage.setItem('token', responseJson.token);
        //  this.props.navigation.navigate('App')
        } else {
          Toast.show('Some error occure');
         // alert(JSON.stringify(responseJson))
        }
      })
      .catch((error) => {
        console.log(error)
        Toast.show('Some error occure'); 
        // alert("Dd")
        // alert(JSON.stringify(error))
      });

  } 

  validate_inputs(text, fieldname) {
    let erroemessage = null;
    switch (fieldname) {
      case 'first_name':
        erroemessage = "First name is Required";
        break;
      case 'last_name':
        erroemessage = "Last name is Required";
        break;
      case 'address':
        erroemessage = "Address is Required";
        break;
      case 'city':
        erroemessage = "City is Required";
        break;
      case 'state':
        erroemessage = "State is Required";
        break;
      case 'country':
        erroemessage = "Country is Required";
        break;
      case 'zip':
        erroemessage = "Zip code is Required";
        break;
      case 'gender':
        erroemessage = "Please select gender";
        break;
    }
    let stateObject = {
      text: text,
      valid: text.length !== 0,
      errmsg: text.length == 0 ? erroemessage : null
    }
    this.setState({ [fieldname]: stateObject }, () => {

    });
  }
  checkvalidation() {
    let validform = true;
    let formdata = this.state
    for (let i in formdata) {
      if ((Object.keys(formdata[i]).length) > 1 && i != 'token') {
        if (formdata[i].valid == false) {
          validform = false;
          switch (i) {
            case 'first_name':
              formdata[i].errmsg = "First name is Required";
              break;
            case 'last_name':
              formdata[i].errmsg = "Last name is Required";
              break;
            case 'address':
              formdata[i].errmsg = "Address is Required";
              break;
            case 'city':
              formdata[i].errmsg = "City is Required";
              break;
            case 'state':
              formdata[i].errmsg = "State is Required";
              break;
            case 'country':
              formdata[i].errmsg = "Country is Required";
              break;
            case 'zip':
              formdata[i].errmsg = "Zip code is Required";
              break;
            case 'gender':
              formdata[i].errmsg = "Please select gender";
              break;
          }

        }
      }
    }
    this.setState(formdata);
    if (validform == false) {
      return false;
    } else {
let postdata=this.state;
let formvalues=[];
for(let j in postdata){
  formvalues[j]=postdata[j].text

}
let token = this.state.token;
let postvalues=Object.assign({}, formvalues)
fetch('http://202.164.42.26:8282/castlesetup/public/api/v1/update-profile', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token

      },
      body: JSON.stringify(postvalues),
    }).then((response) => response.json())
      .then(async (responseJson) => {
        console.log(responseJson)
        if (responseJson.success == 1) {
          Toast.show('Profile Updated Successfully');
        } else {
          Toast.show('Some error occure try later');
        }
      })
      .catch((error) => {
        console.log(error)
        alert("Dd")
        alert(JSON.stringify(error))
      });

    }
  }


  render() {
    return (
      <View style={styles.container}>
        <ScrollView>
          <View style={styles.innercontainer}>
            <View>
              <PhotoUpload
                onPhotoSelect={async (avatar) => {
                  if (avatar) {
                    this.getusertoken(avatar)
                    console.log('Image base64 string: ', avatar)
                  }
                }}
                onTapCustomButton={(avtar)=>{
                  console.log("mitim")
                  console.log(avtar)
                }}
              >
                {
                  this.state.img_loading === true && 
                  <ActivityIndicator style={{
                    position: 'absolute',
                  }}></ActivityIndicator>
                }
                <Avatar
                  key={new Date()}
                  size="xlarge"
                  showEditButton
                  source={{
                    uri: this.state.uri,
                      //'https://s3.amazonaws.com/uifaces/faces/twitter/ladylexy/128.jpg',
                  }} 
                  containerStyle={styles.userimage}
                  overlayContainerStyle={styles.useroverlay}
                  editButton={{
                    style: {
                      marginVertical: -15,
                      marginRight: -10,
                      width: 40,
                      height: 40,
                      borderRadius: 15,
                      position: 'absolute',
                      backgroundColor: "#000",
                    }, 
                    underlayColor: "#000", 
                    onPress: () => {
                      this.selectPhotoTapped();
                    }
                  }}
                />
              </PhotoUpload>
            </View>
            <View style={styles.fullformcss}>

              <View style={styles.fields}>
                <Text style={styles.labels}>First Name</Text>
                <View style={{
                  width: '80%',
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignContent: 'center'
                }}>
                  <Icon.Button
                    name="user"
                    color="#881465"
                    size={20}
                    backgroundColor="#FFFFFF"
                  >
                  </Icon.Button>
                  <TextInput
                    style={styles.input}
                    onChangeText={(text) => this.validate_inputs(text, 'first_name')}
                    autoCapitalize="none"
                    autoCorrect={false}
                    value={this.state['first_name'].text}
                  />

                </View>
                <Text style={styles.error}>{this.state['first_name'].errmsg}</Text>
              </View>

              <View style={styles.fields}>
                <Text style={styles.labels}>Last Name</Text>
                <View style={{
                  width: '80%',
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignContent: 'center'
                }}>
                  <Icon.Button
                    name="user"
                    color="#881465"
                    size={20}
                    backgroundColor="#FFFFFF"
                  >
                  </Icon.Button>
                  <TextInput
                    style={styles.input}
                    onChangeText={(text) => this.validate_inputs(text, 'last_name')}
                    autoCapitalize="none"
                    autoCorrect={false}
                    value={this.state['last_name'].text}
                  />
                </View>
                <Text style={styles.error}>{this.state['last_name'].errmsg}</Text>
              </View>
              <View style={styles.fields}>
                <Text style={styles.labels}>Address</Text>
                <View style={{
                  width: '80%',
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignContent: 'center'
                }}>
                  <Icon.Button
                    name="building"
                    color="#881465"
                    size={20}
                    backgroundColor="#FFFFFF"
                  >
                  </Icon.Button>
                  <TextInput
                    style={styles.input}
                    onChangeText={(text) => this.validate_inputs(text, 'address')}
                    autoCapitalize="none"
                    autoCorrect={false}
                    value={this.state['address'].text}
                  />
                </View>
                <Text style={styles.error}>{this.state['address'].errmsg}</Text>
              </View>

              <View style={styles.fields}>
                <Text style={styles.labels}>City</Text>
                <View style={{
                  width: '80%',
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignContent: 'center'
                }}>
                  <Icon.Button
                    name="home"
                    color="#881465"
                    size={20}
                    backgroundColor="#FFFFFF"
                  >
                  </Icon.Button>
                  <TextInput
                    style={styles.input}
                    onChangeText={(text) => this.validate_inputs(text, 'city')}
                    autoCapitalize="none"
                    autoCorrect={false}
                    value={this.state['city'].text}
                  />
                </View>
                <Text style={styles.error}>{this.state['city'].errmsg}</Text>
              </View>


              <View style={styles.fields}>
                <Text style={styles.labels}>State</Text>
                <View style={{
                  width: '80%',
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignContent: 'center'
                }}>
                  <Icon.Button
                    name="home"
                    color="#881465"
                    size={20}
                    backgroundColor="#FFFFFF"
                  >
                  </Icon.Button>
                  <TextInput
                    style={styles.input}
                    onChangeText={(text) => this.validate_inputs(text, 'state')}
                    autoCapitalize="none"
                    autoCorrect={false}
                    value={this.state['state'].text}
                  />
                </View>
                <Text style={styles.error}>{this.state['state'].errmsg}</Text>
              </View>

              <View style={styles.fields}>
                <Text style={styles.labels}>Country</Text>
                <View style={{
                  width: '80%',
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignContent: 'center'
                }}>
                  <Icon.Button
                    name="flag"
                    color="#881465"
                    size={20}
                    backgroundColor="#FFFFFF"
                  >
                  </Icon.Button>
                  <TextInput
                    style={styles.input}
                    onChangeText={(text) => this.validate_inputs(text, 'country')}
                    autoCapitalize="none"
                    autoCorrect={false}
                    value={this.state['country'].text}
                  />
                </View>
                <Text style={styles.error}>{this.state['country'].errmsg}</Text>
              </View>
              <View style={styles.fields}>
                <Text style={styles.labels}>Zip</Text>
                <View style={{
                  width: '80%',
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignContent: 'center'
                }}>
                  <Icon.Button
                    name="map-pin"
                    color="#881465"
                    size={20}
                    backgroundColor="#FFFFFF"
                  >
                  </Icon.Button>
                  <TextInput
                    style={styles.input}
                    onChangeText={(text) => this.validate_inputs(text, 'zip')}
                    keyboardType='numeric'
                    maxLength={7}
                    autoCapitalize="none"
                    autoCorrect={false}
                    value={this.state['zip'].text}
                  />
                </View>
                <Text style={styles.error}>{this.state['zip'].errmsg}</Text>
              </View>
              <View style={styles.fields}>
                <Text style={styles.labels}>Gender</Text>
                <View style={{
                  width: '80%',
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignContent: 'center'
                }}>
                  <Icon.Button
                    name="intersex"
                    color="#881465"
                    size={20}
                    backgroundColor="#FFFFFF"
                  >
                  </Icon.Button>
                <Picker
                    style={styles.input}
                    onValueChange={(itemValue, itemIndex) =>
                      this.validate_inputs(itemValue, 'gender')
                    }
                    selectedValue={this.state['gender'].text}>
                    <Picker.Item label="Male" value="male" />
                    <Picker.Item label="Female" value="female" />
                  </Picker>

                </View>
                <Text style={styles.error}>{this.state['gender'].errmsg}</Text>
              </View>

              <View>
                <TouchableHighlight
                  onPress={() => this.checkvalidation()}
                  style={styles.button}>
                  <Text style={{
                    textAlignVertical: "center", textAlign: "center",
                    color: '#fff', fontSize: 20, textTransform: 'uppercase',
                  }}>Update Profile</Text>
                </TouchableHighlight>
              </View>

            </View>
          </View>
        </ScrollView>
      </View>
    );
  }
}

const ELEMENT_WIDTH = width - 40;
const styles = StyleSheet.create({
  keyboardstyle: {
    width: '100%',
    backgroundColor: '#eee',
    marginRight: 40,
    marginLeft: 20,
  },
  container: {
    flex: 1,
    //justifyContent: 'center',
    // alignItems: 'center',
    backgroundColor: "#FFFFFF",
    // height: "100%"
  },
  innercontainer: {
    width: '98%',
    alignSelf: 'center'
  },
  userimage: {
    borderBottomWidth: 4,
    borderLeftWidth: 4,
    borderRightWidth: 4,
    borderTopWidth: 4,
    borderBottomColor: "#881465",
    borderLeftColor: "#881465",
    borderRightColor: "#881465",
    borderTopColor: "#881465",
    marginTop: 10,
    borderRadius: 10,
    //  overflow : 'hidden'
  },
  useroverlay: {
    borderBottomColor: "red",
  },
  fullformcss: {
    marginTop: 20,
    display: 'flex',
    alignContent: 'center',
    marginLeft: 20

  },
  input: {
    width: '100%',

    //   borderTopWidth: 1,
    borderBottomWidth: 1,
    //  borderLeftWidth: 1,
    //  borderRightWidth: 1,
    //   borderTopColor: '#ccc',
    borderBottomColor: '#ccc',
    //   borderLeftColor: '#ccc',
    //   borderRightColor: '#ccc',
    //   borderRadius: 20,
    height: 40,
    //  paddingLeft: 15,
    //   paddingRight: 15, 
    marginLeft: 9
  },
  fields: {
    width: "100%",
    marginBottom: 20
  },
  labels: {
    // width: '80%',
    marginLeft: 50
  },
  iconstyle: {
    width: "10%"
  },
  button: {
    width: ELEMENT_WIDTH,
    alignItems: 'center',
    borderRadius: 30,
    marginLeft: 'auto',
    marginRight: 'auto',
    marginTop: 20,
    marginBottom: 20,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderTopColor: '#881465',
    borderBottomColor: '#881465',
    borderLeftColor: '#881465',
    borderRightColor: '#881465',
    backgroundColor: '#881465',
    height: 60,
    maxWidth: '50%',
    paddingTop: 15,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: '500',
    fontSize: 16,
  },
  socialmedia: {
    display: "flex",
    flexWrap: 'wrap',
    padding: 20,
    maxWidth: '80%',
    alignSelf: 'center',
    width: '70%',
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  error: {
    color: "red",
    textAlign: 'left',
    width: '80%',
    paddingLeft: 15,
    //alignSelf : 'flex-start'
  }
});  