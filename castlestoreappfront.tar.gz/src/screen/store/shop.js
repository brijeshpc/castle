import React, { Component } from 'react';
import {
  Button,
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  TextInput,
  TouchableHighlight,
  TouchableOpacity,
  ImageBackground,
  AsyncStorage,
  ScrollView,
  Picker,
  ActivityIndicator,
} from 'react-native';
import Carousel, { Pagination } from 'react-native-snap-carousel';
import SegmentedControlTab from 'react-native-segmented-control-tab'
import Icon from 'react-native-vector-icons/FontAwesome';
import { white } from 'ansi-colors';

const cardWidth = (Dimensions.get('window').width) / 3;
const sliderWidth = Dimensions.get('window').width - 10


export default class Shop extends Component {

  constructor(props, context) {
    super(props, context);
    this.state = {
      data: [],
      token: '',
      carousals: [],
      activeSlide: 0,
      tabs: {
        selectedIndex: 0,
      },
      cat: {
        catageorydata: []
      },
      active: "her"
    }
  }

  async componentDidMount() {
    // let car_images = [];
    // car_images.push({
    //   url: require('../assets/logo.png')
    // },
    //   { url: require('../assets/internal.png') },
    //   { url: require('../assets/offer1.png') },
    //   { url: require('../assets/offer2.png') },
    //   { url: require('../assets/offer3.png') })
    // this.setState({
    //   carousals: car_images
    // })
    this.selectmaincat('her');
    this.getcrasoul();
  }
  
  get pagination() {
    const { entries, activeSlide } = this.state;
    return (
      <Pagination
        dotsLength={this.state.carousals.length}
        activeDotIndex={activeSlide}
        containerStyle={{}}
        dotStyle={{
          width: 10,
          height: 10,
          overflow: 'hidden',
          marginHorizontal: 8,
          backgroundColor: '#FF81B1'
        }}
        inactiveDotStyle={{
          // Define styles for inactive dots here
        }}
        inactiveDotOpacity={0.4}
        inactiveDotScale={0.6}
      />
    );
  }


  _renderItem=({ item, index })=> {
    return (
      <View style={{
        marginTop : 30, 
        width: "100%",
        height: "100%",   
        alignSelf : 'center'
      }}> 
        <Image
          style={{ width: '100%', height: "100%" }}
          source={{ uri: item.url }} 
        />
      </View> 
    )
  }  
  
  // handleIndexChange = (index) => {
  //   this.setState({
  //     ...this.state.tabs,
  //     selectedIndex: index,
  //   });
  // }


  titleCase(str) {
    var splitStr = str.toLowerCase().split('-');
    for (var i = 0; i < splitStr.length; i++) {
      // You do not need to check if i is larger than splitStr length, as your for does that for you
      // Assign it back to the array
      splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
    }
    // Directly return the joined string
    return splitStr.join(' ');
  }



  selectmaincat = (cat) => {
    //alert("ddd")
    //http://202.164.42.26:8282/castlesetup/public/api/v1/section-categories
    let postdata = {
      product_for: cat
    }
    this.setState({active: cat});
    fetch('http://202.164.42.26:8282/castlesetup/public/api/v1/section-categories', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(postdata),
    }).then((response) => response.json())
      .then(async (responseJson) => {
        let catdata = this.state
        if (responseJson.success == 1) {
          console.log(responseJson)
          if (Object.keys(responseJson.data).length > 0) {
            console.log(catdata)
            catdata.cat.catageorydata = [];
            for (let j in responseJson.data) {
              let name = this.titleCase(responseJson.data[j].item_type);
              let itm_type = responseJson.data[j].item_type;
              let image = responseJson.url+responseJson.data[j].item_type+'.png';
              catdata.cat.catageorydata.push({ name: name, item_type: itm_type, image: image })
              //catdata.push()          
            }
            console.log(catdata)
            this.setState(catdata)
          }
        } else {
          alert(JSON.stringify(responseJson))
        }
      })
      .catch((error) => {
        alert(JSON.stringify(error))
      });


    console.log(cat)
  }

  getcrasoul(){
    fetch('http://202.164.42.26:8282/castlesetup/public/api/v1/slider-images', {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    }).then((response) => response.json())
      .then(async (responseJson) => {
        let slidedata = this.state.carousals
        if (responseJson.success == 1) {
          console.log(responseJson)
          slidedata=[];
          if (Object.keys(responseJson.data).length > 0) {
            for (let k in responseJson.data) {
              let slider_image = responseJson.url+responseJson.data[k];
              //'http://202.164.42.26:8282/castlesetup/storage/app/public/categories/vibrator.png';
              slidedata.push({url: slider_image})
            }
            this.setState({carousals: slidedata})
            console.log(this.state)
          }
       
        } else {
          alert(JSON.stringify(responseJson))
        }
      })
      .catch((error) => {
        alert(JSON.stringify(error))
      });

  }
   

  render() {
    return (

      <View style={styles.container}>
        <ScrollView>
        <View style={styles.offer}>
          <View style={styles.offerimage}>
            <Image
              style={{ width: '100%' }}
              source={require('../../assets/offer1.png')}
            />
          </View>
          <View style={styles.offerimage}>
            <Image
              style={{ width: '100%' }}
              source={require('../../assets/offer2.png')}
            />
          </View>
          <View style={styles.offerimage}>
            <Image
              style={{ width: '100%' }}
              source={require('../../assets/offer3.png')}
            />
          </View>
        </View>
        <View style={{
          height: 300, 
          width : '100%',  
        }}>
          <Carousel
            ref={(c) => { this._carousel = c; }}
            data={this.state.carousals}
            renderItem={this._renderItem}
        
            sliderWidth={sliderWidth}
            itemWidth={sliderWidth - 6}
            onSnapToItem={(index) => this.setState({ activeSlide: index })}
          /> 
          {this.pagination}
        </View>
        <View style={styles.maincat}>
          <ScrollView horizontal={true}>
            <TouchableOpacity
              onPress={() => this.selectmaincat('her')}
              style={this.state.active === 'her' ? styles.test_active :styles.test}
            >
              <Icon.Button
                active={true}
                name="venus"
                color="#881465"
                size={20}
                style={{
                  marginVertical : this.state.active === 'her' ? -2 : 0
                }}
                backgroundColor="#FFFFFF"
                onPress={() => this.selectmaincat('her')}
              > 
                <Text>For Her</Text>
              </Icon.Button>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => this.selectmaincat('him')}
              style={this.state.active === 'him' ? styles.test_active : styles.test}
            >
              <Icon.Button
                name="mars"
                color="#881465"
                size={20}
                style={{
                  marginVertical : this.state.active === 'him' ? -2 : 0
                }}
                backgroundColor="#FFFFFF"
                onPress={() => this.selectmaincat('him')}
              >
                <Text>For Him</Text>
              </Icon.Button>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => this.selectmaincat('couples')}
              style={this.state.active === 'couples' ? styles.test_active :styles.test}
            >
              <Icon.Button
                name="users"
                color="#881465"
                size={20}
                style={{
                  marginVertical : this.state.active === 'couples' ? -2 : 0
                }}
                backgroundColor="#FFFFFF"
                onPress={() => this.selectmaincat('couples')}
              >
                <Text>For Couple</Text>
              </Icon.Button>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => this.selectmaincat('fetish')}
              style={this.state.active === 'fetish' ? styles.test_active :styles.test}
            >

              <Icon.Button
                name="users"
                color="#881465"
                size={20}
                style={{
                  marginVertical : this.state.active === 'fetish' ? -2 : 0
                }}
                backgroundColor="#FFFFFF"
                onPress={() => this.selectmaincat('fetish')}
              >
                <Text>Fetish</Text>
              </Icon.Button>

            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => this.selectmaincat('lingerie')}
              style={this.state.active === 'lingerie' ? styles.test_active :styles.test}
            >
             <Icon.Button
                name="users"
                color="#881465"
                size={20}
                style={{
                  marginVertical : this.state.active === 'lingerie' ? -2 : 0
                }}
                backgroundColor="#FFFFFF"
                onPress={() => this.selectmaincat('lingerie')}
              >
                <Text>Lingerie</Text>
              </Icon.Button>
            </TouchableOpacity>
          </ScrollView>
      


        </View>
        <View style={{
          width: "99%",
          paddingLeft: 10,
          flexWrap: 'wrap'
        }}>
          <ScrollView horizontal={true} >
            {

              this.state.cat.catageorydata.map((data, i) => {

                return (
                  <View key={i} style={styles.catagoriees}>
                    <Image style={styles.cat_img} source={{ uri: data.image }} />

                    <View style={styles.cat_name}>
                      <Text style={{ color: 'red', textAlign: 'center' }}>{data.name ? data.name : ''}</Text>
                    </View>
                  </View>
                )
              })
            }

          </ScrollView>
        </View>
        <TouchableOpacity style={{
          alignItems: 'center',
          marginBottom: 10,
          marginTop: 10
          
        }} >
       <Text style={{ 
      borderWidth: 1,
      padding: 6,
      borderColor: 'black',
      backgroundColor: '#666666',
      borderRadius: 50,
      width: '30%',
      textAlign:"center",
      color: "white" 
      }}>VIEW ALL</Text>
       </TouchableOpacity>
        </ScrollView>
      </View>

    );
  }
}
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  test: {
    minWidth: 100,
    height: 35
  },
  test_active:{ 
    minWidth: 100,
    height: 35,
    borderBottomColor: "red",
    borderBottomWidth: 4,
    },
  catagoriees: {
    minWidth: cardWidth,
    minHeight: 80,
    flexWrap: 'wrap',
    flexDirection: 'column'
  },
  title: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  }, 
  offer: {
    width: "97%", 
    marginTop : 10,
    alignItems: 'center',
    alignContent: 'center',
    flexDirection: 'row', 
    justifyContent: 'space-between'
  },
  offerimage: {
    width: '30%',
  },
  carousals: {
    width: "100%",
    height: 400,
    marginTop: 30,
    alignContent: 'center',
    // backgroundColor:'yellow' 
  },
  carousalimage: {
  

  },
  maincat: {
    width: "100%",
    height: 45
  },
  cat_img: {
    height: 100,
    width: 'auto',
    padding: 10
  },
  cat_name: {
    width: '100%',
    backgroundColor: 'beige',
  }
});  