import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Modal,
  Image,
  Dimensions,
  AsyncStorage,
  ScrollView
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5';
// const screenWidth=Dimensions.get('window').width
// const scaleFactor = width / screenWidth
// const imageHeight = height / scaleFactor
const cardWidth = ((Dimensions.get('window').width) - 20) / 3;
export default class Catageory extends Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      modalVisible: false,
      cat_img: '',
      carousals: [],
      bannerWidth: 0,
      bannerHeight: 0,
      cat: {
        catageorydata: []
      },
    }
  }
  async componentDidMount() {
    this.getcrasoul();
    this.getcategory();

  }

  getimage_size() {
    if (this.state.carousals[0].url) {
      Image.getSize(this.state.carousals[0].url, (width, height) => {
        const screenWidth = Dimensions.get('window').width
        const scaleFactor = width / screenWidth
        const imageHeight = height / scaleFactor
        this.setState({ bannerWidth: screenWidth, bannerHeight: imageHeight })
      })
    }
  }


  setModalVisible(visible) {
    this.setState({ modalVisible: visible });
  }



  getcrasoul() {
    fetch('http://202.164.42.26:8282/castlesetup/public/api/v1/slider-images', {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    }).then((response) => response.json())
      .then(async (responseJson) => {
        let slidedata = this.state.carousals
        if (responseJson.success == 1) {
          console.log(responseJson)
          slidedata = [];
          if (Object.keys(responseJson.data).length > 0) {
            for (let k in responseJson.data) {
              let slider_image = responseJson.url + responseJson.data[k];
              //'http://202.164.42.26:8282/castlesetup/storage/app/public/categories/vibrator.png';
              slidedata.push({ url: slider_image })
            }
            this.setState({ carousals: slidedata })
            this.getimage_size();
            console.log(this.state)
          }

        } else {
          alert(JSON.stringify(responseJson))
        }
      })
      .catch((error) => {
        alert(JSON.stringify(error))
      });

  }
  titleCase(str) {
    var splitStr = str.toLowerCase().split('-');
    for (var i = 0; i < splitStr.length; i++) {
      // You do not need to check if i is larger than splitStr length, as your for does that for you
      // Assign it back to the array
      splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
    }
    // Directly return the joined string
    return splitStr.join(' ');
  }

  getcategory() {
    let postdata = {
      product_for: 'her'
    }
    fetch('http://202.164.42.26:8282/castlesetup/public/api/v1/section-categories', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(postdata),
    }).then((response) => response.json())
      .then(async (responseJson) => {
        let catdata = this.state
        if (responseJson.success == 1) {
          console.log(responseJson)
          if (Object.keys(responseJson.all_categories).length > 0) {
            console.log(catdata)
            catdata.cat.catageorydata = [];
            for (let j in responseJson.all_categories) {
              let name = this.titleCase(responseJson.all_categories[j].item_type);
              let itm_type = responseJson.all_categories[j].item_type;
              let image = responseJson.url + responseJson.all_categories[j].item_type + '.png';
              catdata.cat.catageorydata.push({ name: name, item_type: itm_type, image: image })
              //catdata.push()          
            }
            console.log(catdata)
            this.setState(catdata)
          }
        } else {
          alert(JSON.stringify(responseJson))
        }
      })
      .catch((error) => {
        alert(JSON.stringify(error))
      });


    //console.log(cat)
  }




  render() {
    const { bannerWidth, bannerHeight } = this.state
    return (
      <View style={styles.container}>
        <ScrollView>
          <View style={{
            heigh: 350
          }}>

            <Image
              style={
                { width: bannerWidth, height: bannerHeight }
              }
              source={{ uri: this.state.carousals[0] ? this.state.carousals[0].url : '' }}
            ></Image>
          </View>
          <View style={{
            width: '100%',
            flex: 1,
            flexDirection: 'row',
            flexWrap: 'wrap'
          }}>


            <View style={styles.filtersection}>
              <Text style={{
                fontWeight: 'bold',
                color: '#000000'
              }}>
                CATEGORIES
          </Text>
              <TouchableOpacity
                onPress={() => {
                  this.setModalVisible(!this.state.modalVisible);
                }}
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  backgroundColor: "#FFFFFF",
                  borderBottomColor: "#DC1263",
                  borderTopColor: "#DC1263",
                  borderLeftColor: "#DC1263",
                  borderRightColor: "#DC1263",
                  borderBottomWidth: 1,
                  borderTopWidth: 1,
                  borderLeftWidth: 1,
                  borderRightWidth: 1,
                  padding: 4

                }}
              >
                <Icon
                  name="filter"
                  size={16}
                  style={{
                    alignSelf: 'center'
                  }}
                  color="#DC1263"
                ></Icon>
                <Text style={{
                  color: '#DC1263',
                  textAlign: 'center',
                  textAlignVertical: 'center',
                }}>ALL CATEGORIES</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.cat_container}>

              {

                this.state.cat.catageorydata.map((data, i) => {

                  return (
                    <View key={i} style={styles.catagoriees}>
                      <Image style={styles.cat_imgs} source={{ uri: data.image }} />

                      <View>
                        <Text style={{ color: 'red', textAlign: 'center' }}>{data.name ? data.name : ''}</Text>
                      </View>
                    </View>
                  )
                })
              }

 
            </View>
          </View>
        </ScrollView>
        <Modal
          animationType="slide"
          transparent={false}
          visible={this.state.modalVisible}
          onRequestClose={() => {
            alert('Modal has been closed.');
          }}>
          <View style={{ marginTop: 22 }}>
            <View>
              <Text>Hello World!</Text>

              <TouchableOpacity
                onPress={() => {
                  this.setModalVisible(!this.state.modalVisible);
                }}>
                <Text>Hide Modal</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    width: '100%',
    // justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  filtersection: {
    //alignItems: 'center',
    // alignContent: 'center',
    // flexWrap: 'wrap',
    height: 50,
    maxHeight: 50,
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    padding: 8
  },
  cat_container: {
    width: "98%",
    maxWidth: "98%",
    flexWrap: 'wrap',
    flexDirection: 'row',
    marginLeft: '1%',
    alignItems: 'center',
    alignSelf: 'center',
  },
  catagoriees: {
    minWidth: cardWidth,
    padding: 2.5,
    marginLeft: 2.5,
    minHeight: 80,
  },
  cat_imgs: {
    height: 100,
    width: 'auto',
    padding: 5
  } 
});
