import React, { Component } from 'react';
import { AppRegistry, StyleSheet, Text, View, Image, Dimensions, Button, TextInput} from 'react-native';
//import { gestureHandlerRootHOC } from 'react-native-gesture-handler'
//import { Navigation } from 'react-native-navigation';
import Signin from '../screen/user/signin';
import Signup from '../screen/user/signup';
import { TabView, SceneMap } from 'react-native-tab-view';
 
// const FirstRoute = () => (
//   <View style={[styles.scene, { backgroundColor: '' }]} />
// );
// const SecondRoute = () => (
//   <View style={[styles.scene, { backgroundColor: '' }]} />
// );

export default class Login extends Component {
//   static navigationOptions = {
//     header: null
// }
static navigationOptions= {
  headerBackground: (
      <Image 
      resizeMode="cover"
      style={{
        resizeMode:"contain",
        alignSelf:'center',
        height:100
      }}
      source={require('../assets/logo.png')}/>
  ),
  headerStyle: {height: 100}
}



state = {
  index: 0,
  routes: [
    { key: 'first', title: 'LOG IN' },
    { key: 'second', title: 'SIGN UP' },
  ],
  formstate: { email: '',
  password: ''} 
};



_onSubmit() {
  const { username, password } = this.formstate;
  Alert.alert('Button has been pressed!');
}


  render() {
    return (
      //  <View>
      //   <View>
      //    <Image source={require('../assets/logo.png')} style={{width: 193, height: 110}}/>
      //    </View>
         




        <TabView
        navigationState={this.state}
        renderScene={SceneMap({
          first: Signin,
          second: Signup,
        })}
        onIndexChange={index => this.setState({ index })}
        initialLayout={{ width: Dimensions.get('window').width }}
      />
        
      //  </View>
    );
  }

}
const styles = StyleSheet.create({
  scene: {
    flex: 1,
  },
});
