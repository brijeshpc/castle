import React, { Component } from 'react';
import {
  Dimensions,
  Platform,
  AsyncStorage,
  View,
  ScrollView,
  Text,
  TouchableOpacity,


} from 'react-native';
import {
  createAppContainer,
  DrawerActions,
  createDrawerNavigator,
  createStackNavigator,
  createMaterialTopTabNavigator,
  StackNavigator,
  createSwitchNavigator,
  createBottomTabNavigator,
  withNavigation,
  NavigationActions,
  StackActions
} from 'react-navigation';
import { Image } from 'react-native-elements';

import Detail from './screen/store/detail';
import Profile from './screen/user/profile';
import Login from './config/login';
import Signup from './screen/user/signup';
import Signin from './screen/user/signin';
import Catageory from './screen/store/catageories';
import Exclusive from './screen/store/exclusive';
import Shop from './screen/store/shop';
import AuthLoadingScreen from './config/authentication';
import { BorderlessButton } from 'react-native-gesture-handler';
import PropTypes from 'prop-types';
import Icon from 'react-native-vector-icons/FontAwesome5';
import { LoginButton, LoginManager, AccessToken, GraphRequest, GraphRequestManager } from 'react-native-fbsdk';
import { GoogleSignin, GoogleSigninButton, statusCodes } from 'react-native-google-signin';
GoogleSignin.configure({
  scopes: ['https://www.googleapis.com/auth/drive.readonly'], // what API you want to access on behalf of the user, default is email and profile
  webClientId: '822582169843-b0d8jovgsla5tbcggrpuej1250f01udf.apps.googleusercontent.com', // client ID of type WEB for your server (needed to verify user ID and offline access)

});
let screen = Dimensions.get('window');
const TabNavigator = createBottomTabNavigator({

  Shop: {
    screen: Shop,
    navigationOptions: {
      tabBarIcon: ({ tintColor }) => (
        <Icon name="shopping-bag" size={20} />
      ),
    },
  },
  Exclusive:
  {
    screen: Exclusive,
    navigationOptions: {
      tabBarIcon: ({ tintColor }) => (
        <Icon name="crown" size={20} />
      ),
    },
  },
  Catageory: {
    screen: Catageory,
    navigationOptions: {
      tabBarIcon: ({ tintColor }) => (
        <Icon name="bacon" size={20} />
      ),
    },
  }
}, {
    tabBarOptions: {
      showIcon: true,
      activeTintColor: '#F9F9F9', // active icon color
      activeBackgroundColor: '#FF81B1',
      style: {
        backgroundColor: '#AACBEA' // TabBar background
      }
    }
  }
);

const Toptabnavigator = createMaterialTopTabNavigator({
  'LOG IN': Signin,
  'SIGN UP': Signup
}, {
    tabBarOptions: {
      activeTintColor: "#881465",
      inactiveTintColor: "#000000",
      indicatorStyle: {
        backgroundColor: "#881465"

      },
      style: {

        backgroundColor: '#FFFFFF',
        // borderTopWidth: 0,
        // borderTopColor:'#881465',
        // borderTopStyle: 'none'
      }
    }
  })
class LogoTitle extends React.Component {
  render() { 
    return (
      <Image
        resizeMode="cover"
        style={{
          resizeMode: "contain",
          alignSelf: 'center',
          height: 95,
          marginTop: 20,
        }}
        source={require('./assets/logo.png')}
      />
    );
  }
}

class InternalLogo extends React.Component {
  render() {
    return (
      <Image
        resizeMode="cover"
        style={{
          resizeMode: "contain",
          alignSelf: 'center',
          height: 60
        }}
        source={require('./assets/internal.png')}
      />
    );
  }
}

class DrawerScreen extends Component {
  navigateToScreen = (route) => () => {
    const navigateAction = NavigationActions.navigate({
      routeName: route
    });
    this.props.navigation.dispatch(navigateAction);
    this.props.navigation.dispatch(DrawerActions.closeDrawer())
  }

  logout=async()=> {

    const isSignedIn = await GoogleSignin.isSignedIn();
    if(isSignedIn){
      await GoogleSignin.revokeAccess();
      await GoogleSignin.signOut();
    }
    AccessToken.getCurrentAccessToken().then(
      (data) => LoginManager.logOut() //Refresh it every time
  );
    AsyncStorage.clear();
    const resetAction = StackActions.reset({
      index: 0, // <-- currect active route from actions array
      actions: [
        this.props.navigation.navigate('AuthLoading'),
      ],
    });

    //this.props.navigation.dispatch(resetAction);





  }

  render() {
    return (
      <View>
        <ScrollView>
          <View>
            <View style={{
              marginBottom: 10,
              marginTop:10
            }}>
              <Icon
              name="cog"></Icon>
              <Text onPress={this.navigateToScreen('profile')}
              style={{
                fontWeight: "100",
                paddingLeft: 20
              }}
              >
                Account Setting
              </Text> 
            </View>
            <View style={{
              marginBottom: 10,
              marginTop:10
            }}>
              <Icon name ="power-off"></Icon>
              <Text onPress={() => {
                this.logout();
              }}
              style={{
                fontWeight: "100",
                paddingLeft: 20
              }}>
                Logout
              </Text>
            </View>
          </View>
        </ScrollView>
      </View>
    );
  }
 


}
DrawerScreen.propTypes = {
  navigation: PropTypes.object
};



//const AppStack = createStackNavigator({ Home: HomeScreen, Other: OtherScreen });
const AuthStack = createStackNavigator({
  TabScreen: {
    screen: Toptabnavigator,
    navigationOptions: {
      headerStyle: {
        backgroundColor: '#633689',
      },
      headerStyle: {
        height: 110,
        shadowOpacity: 0,
        shadowRadius: 0,
        elevation: 0,

      },
      headerBackground: <LogoTitle />,
    },
  },
}
);
const Loginpage = createStackNavigator({ Signin: Signin })
const signuppage = createStackNavigator({ Signup: Signup })


const DrawerNavigators = createDrawerNavigator({ 
  Home:{
    screen: TabNavigator
},
profile:{
  screen: Profile
}
},{
  contentComponent: DrawerScreen,
  drawerWidth: 300
}
);

const MenuImage = ({ navigation }) => {
  console.log("dfdfss")
  if (!navigation.state.isDrawerOpen) {
    return <Image source={require('./assets/menu-button.png')} />
  } else {
    return <Image source={require('./assets/close.png')} />
  }
}


const menunavigation = createStackNavigator({
  DrawerNavigator: {
    screen: DrawerNavigators,
    navigationOptions: ({ navigation }) => ({
      // title: 'ReactNavigation',  // Title to appear in status bar
      headerLeft:
        <TouchableOpacity onPress={() => { 
         console.log(navigation)
          navigation.dispatch(DrawerActions.toggleDrawer()) 
          }} style={{
            marginLeft:10
          }}>
          <MenuImage style={{
            backgroundColor: "black"
          }} navigation={navigation} />
        </TouchableOpacity>,
        headerRight: <Icon name="bell" size={30} style={{
          marginRight:10
        }}></Icon>,
      headerStyle: {
        backgroundColor: '#fff',
        height: 70,
      }, 
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
      headerBackground: <InternalLogo />,
    }
    )
  }

}
  // {
  //   navigationOptions: ({ navigation }) => ({
  //       title: 'ReactNavigation',  // Title to appear in status bar
  //       headerLeft: 
  //       <TouchableOpacity  onPress={() => {navigation.dispatch(DrawerActions.toggleDrawer())} }>
  //           <MenuImage style="styles.bar" navigation={navigation}/>
  //       </TouchableOpacity>,
  //       headerStyle: {
  //           backgroundColor: 'red',
  //       },
  //       headerTintColor: '#fff',
  //       headerTitleStyle: {
  //         fontWeight: 'bold',
  //       },
  //     }
  // )
  //   }
)
 
 


export default createAppContainer(createSwitchNavigator(
  {
    AuthLoading: AuthLoadingScreen,
    App: menunavigation,
    Auth: AuthStack,
    logindata: Loginpage,
    signuppage: signuppage, 
  },
  {
    initialRouteName: 'AuthLoading',
  }
))

  //  const token = await AsyncStorage.getItem('token');
  // if(token == null){
  //   return createAppContainer(TabNavigator);
  // }else{
  //   createAppContainer(TabNavigator);
//  }  





